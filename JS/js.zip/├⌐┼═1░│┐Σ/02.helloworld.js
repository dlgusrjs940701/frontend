// 자바 스크립트의 주석(comment)
console.log('Hello world!!!')

/*
/* 반복문 - 여러줄에 걸쳐서 주석을 작성하는 경우
*/
let sum = 0;
for (let i = 1; i <= 10000; i++) {
    sum += i;
}
console.log('1에서 10000까지의 합은', sum);

// 편하게 주석다는 방법 - 마우스로 선택한 후 컨트롤 + /