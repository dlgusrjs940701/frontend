console.log('프로그램이 시작되었습니다.');

console.rog('괄호를 닫지 않는 실수를 저질렀습니다.')